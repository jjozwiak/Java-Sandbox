public class PlayerScore
{

}